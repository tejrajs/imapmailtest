<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
/* @var $this yii\web\View */

$this->title = 'My Yii Application';

?>
<div class="site-index">
	<?php echo '<pre>';print_r($mailDetail);?>
</div>